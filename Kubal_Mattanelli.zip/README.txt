The R code provided in the Code.R file should be sufficient for the replication of our analysis. 
In the first few lines we load the data from Yahoo Finance in the same manner as in the code provided by the lecturer. 
We extended the period to April 2022 in order to keep our analysis up-to-date and also to be able to assess the impact
of the Russian invasion of Ukraine.